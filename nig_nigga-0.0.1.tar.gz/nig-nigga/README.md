======
2048-in-terminal
======


![screensho](https://github.com/alewmoose/at2048/blob/master/screenshot.png)


======
Build and install
======

make

sudo make install


========
The original game: http://gabrielecirulli.github.io/2048/
